package com.access.server.enums;

public enum ErrorCodeEnum {


    /**
     * GLOBAL 10011041 error code enum.
     */
    GL99990100(0100, "参数异常"),
    GL99990404(0404, "访问路径不存在"),
    GL99990417(0417, "操作失败"),
    GL99990401(0401, "无访问权限"),
    GL99990101(0101, "token is invalid"),

    UAC10010102(0102, "token已过期,请重新登录"),


    PUB10000001(10000001, "文件上传失败"),
    PUB10000002(10000002, "插入失败"),
    PUB10000003(10000003, "删除失败"),
    PUB10000004(10000004, "文件不能为空"),


    SYS20000001(20000001, "登录失败"),
    SYS20000002(20000002, "账号不存在"),
    SYS20000003(20000003, "密码错误"),
    SYS20000004(20000004, "账号已存在"),
    SYS20000005(20000005, "账号已被禁用"),
    SYS10011006(10011006, "密码错误"),
    SYS10000007(10000007, "暂无权限操作");


    private int code;
    private String msg;

    /**
     * Msg string.
     * @return the string
     */
    public String msg() {
        return msg;
    }

    /**
     * Code int.
     * @return the int
     */
    public int code() {
        return code;
    }

    ErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * Gets enum.
     * @param code the code
     * @return the enum
     */
    public static ErrorCodeEnum getEnum(int code) {
        for (ErrorCodeEnum ele : ErrorCodeEnum.values()) {
            if (ele.code() == code) {
                return ele;
            }
        }
        return null;
    }

}