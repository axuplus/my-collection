package com.access.server.utils.controller;

import com.access.server.enums.ErrorCodeEnum;
import com.access.server.exceptions.BizException;
import com.access.server.model.dto.LoginAuthDto;
import com.access.server.model.dto.LoginTokenDto;
import com.access.server.utils.PublicUtil;
import com.access.server.utils.ThreadLocalMap;
import com.access.server.utils.constant.GlobalConstant;
import com.access.server.utils.wrapper.WrapMapper;
import com.access.server.utils.wrapper.Wrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseController {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    protected LoginAuthDto getLoginAuthDto() {
        LoginTokenDto loginTokenDto = (LoginTokenDto) ThreadLocalMap.get(GlobalConstant.Sys.TOKEN_AUTH_DTO);
        if (PublicUtil.isEmpty(loginTokenDto)) {
            throw new BizException(ErrorCodeEnum.UAC10010102);
        }
        logger.error("获取到的用户信息是-------------> {}", loginTokenDto);
        LoginAuthDto loginAuthDto = new LoginAuthDto();
        loginAuthDto.setUserId(loginTokenDto.getId());
        loginAuthDto.setUserName(loginTokenDto.getUserName());
        loginAuthDto.setType(loginTokenDto.getType());
        return loginAuthDto;
    }


    /**
     * Handle result wrapper.
     * @param <T>    the type parameter
     * @param result the result
     * @return the wrapper
     */
    protected <T> Wrapper<T> handleResult(T result) {
        boolean flag = isFlag(result);

        if (flag) {
            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "操作成功", result);
        } else {
            return WrapMapper.wrap(Wrapper.ERROR_CODE, "操作失败", result);
        }
    }

    /**
     * Handle result wrapper.
     * @param <E>      the type parameter
     * @param result   the result
     * @param errorMsg the error msg
     * @return the wrapper
     */
    protected <E> Wrapper<E> handleResult(E result, String errorMsg) {
        boolean flag = isFlag(result);

        if (flag) {
            return WrapMapper.wrap(Wrapper.SUCCESS_CODE, "操作成功", result);
        } else {
            return WrapMapper.wrap(Wrapper.ERROR_CODE, errorMsg, result);
        }
    }

    private boolean isFlag(Object result) {
        boolean flag;
        if (result instanceof Integer) {
            flag = (Integer) result > 0;
        } else if (result instanceof Boolean) {
            flag = (Boolean) result;
        } else {
            flag = PublicUtil.isNotEmpty(result);
        }
        return flag;
    }

}