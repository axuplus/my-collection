package com.access.server.model.dto;

import lombok.Data;

@Data
public class TokenDto {
    private String userName;
    private String password;
}