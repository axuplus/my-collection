package com.access.server.controller;

import com.access.server.model.dto.TokenDto;
import com.access.server.model.vo.LoginTokenVo;
import com.access.server.service.TokenService;
import com.access.server.utils.controller.BaseController;
import com.access.server.utils.wrapper.WrapMapper;
import com.access.server.utils.wrapper.Wrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * token Controller
 */
@RestController
@RequestMapping(value = "/admin")
@Api(value = "token接口", tags = {"token接口"})
public class TokenController extends BaseController {


    @Autowired
    private TokenService tokenService;

    /**
     * 获取token
     */
    @PostMapping(value = "/token")
    @ApiOperation(value = "获取token", notes = "获取token")
    public Wrapper<LoginTokenVo> token(@RequestBody TokenDto tokenDto) {
        final LoginTokenVo result = tokenService.token(tokenDto.getUserName(), tokenDto.getPassword());
        return WrapMapper.ok(result);
    }

    /**
     * 退出系统
     */
    @GetMapping(value = "/exit")
    @ApiOperation(value = "退出系统", notes = "退出系统")
    public Wrapper exit(@RequestParam("userId") Long userId) {
        final Boolean flag = tokenService.exit(userId);
        if (flag) {
            return WrapMapper.ok("退出成功");
        }
        return WrapMapper.wrap(100002, "退出失败");
    }
}