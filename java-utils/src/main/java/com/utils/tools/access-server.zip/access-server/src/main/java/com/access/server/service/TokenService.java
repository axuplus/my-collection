package com.access.server.service;

import com.access.server.model.entity.SysAdmin;
import com.access.server.model.vo.LoginTokenVo;
import com.baomidou.mybatisplus.extension.service.IService;

public interface TokenService extends IService<SysAdmin> {

    LoginTokenVo token(final String account, final String pwd);

    Boolean exit(final Long userId);

}