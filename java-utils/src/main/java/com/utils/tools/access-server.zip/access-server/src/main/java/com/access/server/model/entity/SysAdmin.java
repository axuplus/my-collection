package com.access.server.model.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class SysAdmin {

    /**
     * ID
     */
    private Long id;
    /**
     * 密码
     */
    private String password;

    /*
     * 名称
     */
    private String userName;

    /**
     * 状态 0：禁用，1：正常
     */
    private Integer state;

    /**
     * 创建人
     */
    private Long createUser;

    /**
     * 层级
     */
    private Integer level;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;


}