package com.access.server.model.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserTokenDto implements Serializable {

    private static final long serialVersionUID = -1137852221455042256L;
    private Long userId;
    private String userName;
    private String token;
    private Integer type;
    private Long expireTime;
    private Long createTime;
}